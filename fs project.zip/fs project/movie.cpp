#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <limits>
#include <time.h>
#include <math.h>
#include <process.h>
#include <regex>
// #include <ctype.h>
// #include <bits/stdc++.h>

// #define ENTER 13
// #define TAB 9
#define BKSP 8

using namespace std;

class movie
{
public:
	char moviename[15], seats[15], price[5], pass[20], buffer[100], name[20], movieid[10], seatnum[10], ind[5], s_num[10],
		st_no[5], num[11], age[10];
} stdrec[50];

class login
{
public:
	char name[20], pass[25], buffer[100];
};

regex pasw("[A-Z][a-z0-9]{7,}");
regex number("[^a-z^A-Z] ");
regex age("[0-9]{2}");
movie m2[100];
void displaymovie();
void displayFile();
int main();
void bookmovie();
void search_tickets();
void modify_tickets();
void delete_record();
void create_indexfile();
void pay();

int checkname(char name[10])
{
	fstream in;
	login l;
	in.open("userslist.txt", ios::in);
	while (!in.eof())
	{
		in.getline(l.name, 10, '|');
		in.getline(l.pass, 20, '\n');

		if (strcmp(l.name, name) == 0)
		{
			return 1;
		}
	}
	in.close();
}

void newuser()
{
	fstream app;
	login l;
	int i = 0;
	char ch;
	app.open("userslist.txt", ios::out | ios::app); //Open file in append mode
	if (!app)
	{
		cout << "Cannot open the file in output mode";
		exit(0);
	}
	while (1)
	{
		cout << "\nEnter The Username = ";
		cin >> l.name;
		if (checkname(l.name) == 1)
		{
			cout << "\nUsername is already exists, Try Another...!!\n";
		}
		else
		{
			break;
		}
	}
	cout << "\nEnter The Password(First character Must be capital and your password Must contains letters and Numbers Only of length 8) = ";
	cin >> l.pass;
	while (!regex_match(l.pass, pasw))
	{
		if (!cin)
			break;
		cout << "Enter valid Password \t :";
		cin >> l.pass;
	}
	// while (1)
	// {
	// 	ch = getch();
	// 	if (ch == BKSP)
	// 	{
	// 		if (i > 0)
	// 		{
	// 			i--;
	// 			cout << "\b \b";
	// 		}
	// 	}
	// 	else
	// 	{
	// 		l.pass[i++] = ch;
	// 		cout << "* \b";
	// 	}
	// }

	// while (l.pass[i - 1] != '\r')
	// {
	// 	l.pass[i] = getch();
	// 	if (l.pass[i - 1] != '\r')
	// 	{
	// 		cout << "*";
	// 	}
	// 	i++;
	// }
	// l.pass[i - 1] = '\0';
	// cout << endl;

	// cin >> l.pass;

	cout << "\n**********Registered Succesfully*************";
	strcpy(l.buffer, l.name);
	strcat(l.buffer, "|");
	strcat(l.buffer, l.pass);
	strcat(l.buffer, "\n");

	app << l.buffer; //writing the packed information to buffer
	app.close();
}

void existinguser()
{
	fstream in;
	char name[10], pass[10];
	in.open("userslist.txt", ios::in);
	if (!in)
	{
		cout << "\nUnable to open the file in input mode";
		return;
	}
	cout << "\nEnter The Username = ";
	cin >> name;
	cout << "\nEnter The Password = ";
	cin >> pass;
	login l;
	while (!in.eof())
	{
		in.getline(l.name, 10, '|');
		in.getline(l.pass, 10, '\n');

		if (strcmp(l.name, name) == 0 && strcmp(l.pass, pass) == 0)
		{
			cout << "\n Logged in Successfully...!! \n";
			displaymovie();
		}
	}

	cout << "\n Enter valid name and password";
	existinguser();
	// return;
}

void forgotpass()
{
	char name[10];
	fstream in;
	in.open("userslist.txt", ios::in);

	if (!in)
	{
		cout << "\nCannot open the file in output mode";
		return;
	}
	cout << "\n Enter Your Username = ";
	cin >> name;
	login l;
	while (!in.eof())
	{
		in.getline(l.name, 10, '|');
		in.getline(l.pass, 10, '\n');
		if (strcmp(l.name, name) == 0)
		{
			cout << "\nYour Password is = " << l.pass;
			main();
		}
	}
	cout << "\n Enter valid Username or you are Still not yet Registered";
	return;
}

void displaymovie()
{

	int choice;
	for (;;)
	{
		cout << "\n$==================================================&\n";
		cout << "\n		0:exit";
		cout << "\n		1:View Available Movies";
		cout << "\n		2:Book a ticket";
		cout << "\n		3:Search ticket details";
		cout << "\n		4:Modify ticket details";
		cout << "\n		5:Delete ticket\n";
		cout << "\n$==================================================&";
		cout << "\n\nEnter the choice : ";
		cin >> choice;

		switch (choice)
		{
		case 1:
			displayFile();
			break;
		case 2:
			bookmovie();
			break;
		case 3:
			search_tickets();
			break;
		case 4:
			modify_tickets();
			break;
		case 5:
			delete_record();
			break;
		case 0:
			main();
		default:
			cout << "\nInvalid input...";
			break;
		}
	}
}

void displayFile()
{
	movie m;
	int c, I;

	fstream in;

	in.open("movienames.txt", ios::in);

	if (!in)
	{
		cout << "\nCannot open the file in output mode";
		return;
	}

	I = 0;
	cout << "\n$---------------------------------------------------------------------&\n";
	cout << "Movie_id"
		 << "\t\t"
		 << "MovieName"
		 << "\t\t"
		 << "Seats"
		 << "\t\t"
		 << "Price" << endl;
	cout << "$------------------------------------------------------------------------&\n";
	while (!in.eof())
	{
		in.getline(m.movieid, 10, '|');
		in.getline(m.moviename, 15, '|');
		in.getline(m.seats, 15, '|');
		in.getline(m.price, 5, '\n');
		cout << "\n"
			 << m.movieid << "\t\t" << m.moviename << "\t\t" << m.seats << "\t\t" << m.price;

		I++;
	}
	cout << "\n$------------------------------------------------------------------------&\n";
	in.close();
}

int checkmovieid(char movieid[10])
{
	fstream in;
	movie m;
	in.open("movienames.txt", ios::in);
	while (!in.eof())
	{
		in.getline(m.movieid, 10, '|');
		in.getline(m.moviename, 15, '|');
		in.getline(m.seats, 15, '|');
		in.getline(m.price, 5, '\n');

		if (strcmp(m.movieid, movieid) == 0)
		{
			return 1;
		}
	}
	in.close();
}

int checkseatnum(char s_num[10], char movieid[10])
{

	fstream in;
	movie m;
	in.open("secindex.txt", ios::in);
	if (!in)
	{
		return 0;
	}
	while (!in.eof())
	{
		in.getline(m.movieid, 10, '|');
		in.getline(m.seatnum, 10, '|');
		in.getline(m.ind, 5, '\n');

		if (strcmp(m.seatnum, s_num) == 0 && strcmp(m.movieid, movieid) == 0)
		{
			return 1;
		}
	}
	in.close();
}

int get_num_records()
{
	int I = 0;
	fstream file2;
	file2.open("record.txt", ios::in);
	if (!file2)
	{
		return 0;
	}
	while (!file2.eof())
	{
		file2.getline(stdrec[I].ind, 5, '|');
		file2.getline(stdrec[I].movieid, 10, '|');
		file2.getline(stdrec[I].name, 10, '|');
		file2.getline(stdrec[I].age, 10, '|');
		file2.getline(stdrec[I].num, 11, '|');
		file2.getline(stdrec[I].seatnum, 10, '\n');
		I++;
	}
	I--;
	file2.close();
	return I;
}

void create_indexfile(int no, char movieid[10], char name[20], char age[5], char num[11], char seatnum[10])
{

	fstream file1, file2;
	int i;
	char buf1[100], buf2[30];

	movie m;
	file1.open("secindex.txt", ios::out | ios::app);
	file2.open("record.txt", ios::out | ios::app);
	for (i = no; i < no + 1; i++)
	{
		sprintf(buf2, "%s|%s|%d\n", movieid, seatnum, i);
		file1 << buf2;
		sprintf(buf1, "%d|%s|%s|%s|%s|%s\n", i, movieid, name, age, num, seatnum);
		file2 << buf1;
	}
	file1.close();
	file2.close();
	return;
}

void pay(int bill, int cnt, char movieid[10], char seatnum[10], char num[11])
{
	char cname[20], cno[17];
	int expirymm, expiryyy;
	time_t t = time(NULL);
	tm *timePtr = localtime(&t);
	cout << "\npaying using ATM card\n";
	cout << "\nEnter card Holder Name \t :";
	cin >> cname;
	cout << "\nenter the card number \t :";
	cin >> cno;
	cout << "\nExpiry(MM/YYYY) :";
	cin >> expirymm;
	cout << "/";
	cin >> expiryyy;
	while ((expirymm <= 0) || (expirymm > 12) || (expiryyy < (timePtr->tm_year + 1900)))
	{
		if ((expirymm <= 0) || (expirymm > 12))
		{
			cout << "\nenter the month again\t:";
			cin >> expirymm;
		}
		if (expiryyy < (timePtr->tm_year + 1900))
		{
			cout << "\nenter valid year again";
			cin >> expiryyy;
		}
	}
	cout << "Enter the cvv :";
	char password[3];
	int i = 0;
	while (i < 3)
	{
		password[i] = getch();
		cout << "*";
		++i;
	}
	password[i] = '\0';
	fstream app;
	app.open("payment.txt", ios::out | ios::app);
	if (!app)
	{
		cout << "error in opening file";
		exit(0);
	}
	app << cnt << "|" << num << "|" << movieid << "|" << seatnum << "|" << bill << "\n";
	return;
}
void bookmovie()
{
	fstream file1, file2;
	movie m;
	int i, cnt, tic_no, bill;
	char ch, confirm;

bookagain:
	cnt = get_num_records();

	i = cnt;
	while (1)
	{
		cout << "\n Enter the movie id you want to book = ";
		cin >> m.movieid;
		if (checkmovieid(m.movieid) == 1)
		{
			break;
		}
		else
		{
			cout << "Please enter valid movie id";
		}
	}
	cout << "\nEnter  your name = ";
	cin >> m.name;
	cout << "\nEnter Your Age =";
	cin >> m.age;
	while (!regex_match(m.age, age))
	{
		if (!cin)
			break;
		cout << "Enter Valid Age = ";
		cin >> m.age;
	}
	cout << "\nEnter your phone number = ";
	cin >> m.num;
	// int flag2;
	// for (int k = 0; k < stdrec[i].num.length(); k++)
	// {
	// 	if (stdrec[i].num[k] - 48 >= 0 && stdrec[i].num[k] - 48 <= 9)
	// 	{
	// 		flag2 = 1;
	// 		continue;
	// 	}
	// 	else
	// 	{
	// 		flag2 = 0;
	// 		break;
	// 	}
	// }
	// if (flag2 = 1 && stdrec[i].num->length() == 8)
	// {
	// 	break;
	// }
	// else if (flag2 == 0)
	// {
	// 	cin >> stdrec[i].num;
	// }
	// else
	// {
	// 	cin >> stdrec[i].num;
	// }
	// while (!regex_match(m.num, number))
	// {
	// 	if (!cin)
	// 		break;
	// 	cout << "Enter Integers only";
	// 	cin >> m.num;
	// }
	if (strlen(m.num) != 10)
	{
		cout << "Enter valid 10 digit number =";
		cin >> m.num;
	}
	// cout << "Enter the number of TICKETS you want to book = ";
	// cin >> tic_no;
	// if (tic_no >= 5)
	// {
	// 	cout << "You can book less than 5 tickets only";
	// 	cin >> tic_no;
	// }
	// for (i = cnt; i < (cnt + tic_no); i++)
	// {
	// 	while (1)
	// 	{
	// 		cout << "\n Enter the movie id you want to book = ";
	// 		cin >> m.movieid;
	// 		if (checkmovieid(m.movieid) == 1)
	// 		{
	// 			break;
	// 		}
	// 		else
	// 		{
	// 			cout << "Please enter valid movie id";
	// 		}
	// 	}

	// for (i = cnt; i < (cnt + tic_no); i++)
	// {
	while (1)
	{
		cout << "\nEnter the seat number(1-50) = ";
		cin >> m.seatnum;
		if (checkseatnum(m.seatnum, m.movieid) == 1)
		{
			cout << "oh Sorry, Entered seat number is already booked by Someone Please select other Seat number..! ";
		}
		else
		{
			break;
		}
	}
	// }
	// sprintf(buf2, "%s|%s|%d\n", m.movieid, m.seatnum, i);
	// sprintf(buf1, "%d|%s|%s|%s|%s\n", i, m.movieid, m.name, m.num, m.seatnum);
	// }
	// app << i << "|" << stdrec[i].movieid << "|" << stdrec[i].name << "|" << stdrec[i].num << "|" << stdrec[i].seatnum << "\n";
	// app.close();
	// }
	// sprintf(m.buffer, "%d|%s|%s|%s|%s\n", i, m.movieid, m.name, m.num, m.seatnum);
	// cout << "\n****Your Tickets Confirmed..!!****\n";
	cout << "\nYour Total Amount = ";
	// m.bill = "200";
	// cout << m.bill;
	bill = 200;
	cout << bill;
	cout << "\nAre you sure want to confirm this ticket(y/n)";
	cin >> ch;
	while (1)
	{
		if (ch == 'n' || ch == 'N')
		{
			return;
		}
		else if (ch == 'y' || ch == 'Y')
		{
			pay(bill, cnt, m.movieid, m.seatnum, m.num);
			cout << "\nWait a second for conformation....!";
			create_indexfile(cnt, m.movieid, m.name, m.age, m.num, m.seatnum);

			break;
		}
		else if (ch != 'Y' || ch != 'y')
		{
			cout << "\nWrong Input Try Again (y/n) :";
			cin >> ch;
		}
	}
	cout << "\n Your Ticket Booked succesfully";
	cout << "\n Do you want to book one more ticket (y/n)? ";
	cin >> confirm;
	while (1)
	{
		if (confirm == 'n' || confirm == 'N')
		{
			return;
		}
		else if (confirm == 'y' || confirm == 'Y')
		{
			goto bookagain;
		}
		else if (confirm != 'Y' || confirm != 'y')
		{
			cout << "Wrong Input Try Again (y/n) :";
			cin >> confirm;
		}
	}
	// app << m.buffer;

	// app.close();
}

void retrieve_details(char st_no[5])
{
	int no, j, i;
	fstream app;
	movie m;
	no = get_num_records();
	cout << no;
	for (i = 0; i < no; i++)
	{
		if (strcmp(stdrec[i].ind, st_no) == 0)
		{
			cout << "\n\n"
				 << "&------Ticket details------&";
			cout << "\nMovieId    : " << stdrec[i].movieid << "\nName   : " << stdrec[i].name << "\nAge   :" << stdrec[i].age << "\nNumber  : "
				 << stdrec[i].num << "\nSeatNumber    : " << stdrec[i].seatnum
				 << "\n";
		}
	}
}

void search_tickets()
{
	int I, flag1;
	char mid[10], snum[10];
	fstream in;

	cout << "\nEnter The movie id : \n";
	cin >> mid;
	cout << "\nEnter the seat number : \n";
	cin >> snum;
	in.open("secindex.txt", ios::in);
	if (!in)
	{
		cout << "\nError !\n";
		exit(0);
	}
	flag1 = 0;
	movie m;
	while (!in.eof())
	{
		in.getline(m.movieid, 10, '|');
		// in.getline(stdrec[I].name, 10, '|');
		// in.getline(stdrec[I].age, 5, '|');
		// in.getline(stdrec[I].num, 11, '|');
		in.getline(m.seatnum, 10, '|');
		in.getline(m.ind, 5, '\n');

		// in.getline(stdrec[I].bill, 5, '\n');

		if (strcmp(m.movieid, mid) == 0 && strcmp(m.seatnum, snum) == 0)
		{
			retrieve_details(m.ind);
			flag1 = 1;
			break;
		}
	}
	if (!flag1)
		cout << "\nNO ticket found !!\n";
	in.close();
}

void modify_tickets()
{
	fstream in;
	char mid[5], buffer[45], snum[5];
	int I = 0, j;
	movie m1[100];

	in.open("record.txt", ios::in);

	if (!in)
	{
		cout << "\nUnable to open the file in input mode";
		return;
	}

	cout << "\nEnter the movie id : ";
	cin >> mid;
	cout << "\nEnter the seat number : ";
	cin >> snum;
	while (!in.eof())
	{
		// cout << "hii";
		in.getline(m1[I].ind, 5, '|');
		in.getline(m1[I].movieid, 10, '|');
		in.getline(m1[I].name, 10, '|');
		in.getline(m1[I].age, 10, '|');
		in.getline(m1[I].num, 11, '|');
		in.getline(m1[I].seatnum, 10, '\n');
		I++;
	}

	I--;
	cout << I;
	for (j = 0; j < I; j++)
	{
		if (strcmp(mid, m1[j].movieid) == 0 && strcmp(snum, m1[j].seatnum) == 0)
		{
			// cout << "\nThe old values of the record with usn " << usn << " are ";
			// cout << "\nname   = " << m1[j].ind;
			cout << "\n movie id    = " << m1[j].movieid;
			cout << "\n name    = " << m1[j].name;
			cout << "\n Age = " << m1[j].age;
			cout << "\n number    = " << m1[j].num;
			cout << "\n seatnum = " << m1[j].seatnum;

			cout << "\n&--------Enter the new values--------& \n";
			cout << "\n NOTE: movie id can't be changed";
			cout << "\n name   = ";
			cin >> m1[j].name;
			cout << "\n Age  =";
			cin >> m1[j].age;
			cout << "\n number    = ";
			cin >> m1[j].num;
			if (strlen(m1[j].num) != 10)
			{
				cout << "\nEnter valid 10 digit number =";
				cin >> m1[j].num;
			}
			cout << "\n seatnum    = ";
			cin >> m1[j].seatnum;
			// cout << "\nsem    = ";
			// cin >> s1[j].sem;
			// cout << "\nbranch = ";
			// cin >> s1[j].branch;

			break;
		}
	}

	if (j == I)
	{
		cout << "\nEntered Movie id or Seat number is not there";
		return;
	}

	in.close();
	fstream out1, out2, out3;
	char buf1[100], buf2[30], buf3[50];

	out1.open("record.txt", ios::out);
	out2.open("secindex.txt", ios::out);
	out3.open("payment.txt", ios::out);
	if (!out1)
	{
		cout << "\nUnable to open the file in output mode";
		return;
	}

	for (j = 0; j < I; j++)
	{
		sprintf(buf2, "%s|%s|%d\n", m1[j].movieid, m1[j].seatnum, j);
		out2 << buf2;
		sprintf(buf1, "%d|%s|%s|%s|%s|%s\n", j, m1[j].movieid, m1[j].name, m1[j].age, m1[j].num, m1[j].seatnum);
		out1 << buf1;
		sprintf(buf3, "%d|%s|%s|%s|%s\n", j, m1[j].num, m1[j].movieid, m1[j].seatnum, "200");
		out3 << buf3;
		// strcpy(buffer,);
		// strcat(buffer, "|");
		// strcat(buffer, );
		// strcat(buffer, "|");
		// strcat(buffer, m1[j].name);
		// strcat(buffer, "|");
		// strcat(buffer, );
		// strcat(buffer, "|");
		// strcat(buffer, );

		/*int count=strlen(buffer);
	count += 3; */

		/*for(int k=0; k < (45 - count); k++)
	strcat(buffer,"!"); */
	}

	out1.close();
	out2.close();
}

void delete_stdrecord(char st_no[5])
{

	fstream file1, file2, file3, app;
	char ch, ac_no[15], ifsc[10], buf[100];
	int I = 0, no;
	no = get_num_records();
	int flag = -1;
	for (I = 0; I < no; I++) //Check for the record'stdrec existence
	{
		if (strcmp(stdrec[I].ind, st_no) == 0)
		{
			cout << "Are you sure want to delete this Ticket!(y/n) : ";
			cin >> ch;
			while (1)
			{
				if (ch == 'Y' || ch == 'y')
				{
					cout << "\nPlease Enter your Bank Details for Amount Refund = ";
					cout << "\n Account Number =";
					cin >> ac_no;
					cout << "\nEnter Bank IFSC Code = ";
					cin >> ifsc;
					app.open("refund.txt", ios::out | ios::app);
					sprintf(buf, "%s|%s\n", ac_no, ifsc);
					app << buf;
					app.close();
					flag = I;
					break;
				}
				else if (ch == 'N' || ch == 'n')
				{
					return;
				}
				else
				{
					cout << "Invalid Input";
					cin >> ch;
				}
			}
		}
	}
	if (flag == -1) //Record not found
	{
		cout << "\nError !\n";
		return;
	}
	if (flag == (no - 1)) //Delete found last record
	{
		no--;
		cout << "\nDeleted Successfully..!\n";
		cout << "\n Your Amount will be refunded to your bank account within 3 to 4 working days...!";
	}
	else
	{
		for (I = flag; I < no; I++)
		{
			stdrec[I] = stdrec[I + 1];
		}
		no--;
		cout << "\nDeleted Successfully..!\n";
		cout << "\n Your Amount will be refunded to your bank account within 3 to 4 working days...!";
	}

	file1.open("secindex.txt", ios::out);
	file2.open("record.txt", ios::out);
	file3.open("payment.txt", ios::out);
	for (I = 0; I < no; I++)
	{
		file1 << stdrec[I].movieid << "|" << stdrec[I].seatnum << "|" << I << "\n";

		file2 << stdrec[I].ind << "|" << stdrec[I].movieid << "|" << stdrec[I].name << "|" << stdrec[I].num << "|" << stdrec[I].seatnum << "\n";
		file3 << I << "|" << stdrec[I].num << "|" << stdrec[I].movieid << "|" << stdrec[I].seatnum << "|"
			  << "200"
			  << "\n";
	}
	file1.close();
	return;
}

void delete_record()
{
	int I, flag;
	char mid[10], snum[10];
	fstream in;

	cout << "\nEnter The movie id : \n";
	cin >> mid;
	cout << "\nEnter The seat number : \n";
	cin >> snum;
	in.open("secindex.txt", ios::in);
	if (!in)
	{
		cout << "\nError !\n";
		exit(0);
	}
	flag = 0;
	movie m;
	while (!in.eof())
	{
		in.getline(m.movieid, 10, '|');
		in.getline(m.seatnum, 10, '|');
		in.getline(m.ind, 5, '\n');

		if (strcmp(m.movieid, mid) == 0 && strcmp(m.seatnum, snum) == 0)
		{
			delete_stdrecord(m.ind);
			flag = 1;
			break;
		}
	}
	if (!flag)
		cout << "\nDeletion failed..!\n";
	in.close();
}

int main()
{

	int choice;

	for (;;)
	{
		cout << "\n$=======================================================$\n";
		cout << "\n-----------------Movie ticket Booking-------------------\n";
		cout << "\n		0:Exit";
		cout << "\n		1:New user";
		cout << "\n		2:Existing user";
		cout << "\n		3:Forgot Password?\n";
		cout << "\n$=======================================================$\n";
		cout << "\nEnter The Choice : ";
		cin >> choice;

		switch (choice)
		{
		case 1:
			newuser();
			break;
		case 2:
			existinguser();
			break;
		case 3:
			forgotpass();
			break;
		case 0:
			exit(0);
		default:
			cout << "\nInvalid input...!!";
			break;
		}
	}
}
